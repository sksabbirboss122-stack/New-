# GlowShield Browser 1.0.0 — Android source project

A Bangla, native Android WebView browser with a local ad/tracker filter, popup blocking, HTTPS-only navigation, Android Safe Browsing, and warning screens for recognized adult websites. No account, custom backend, advertising SDK, or analytics SDK is included. Internet permission only. Uses Google search as the default search provider; websites and the search provider may still collect information. The browser uses Android's Safe Browsing infrastructure when available.

## Build an APK

**This ZIP contains source, not an APK.** The authoring environment had no Android SDK, Gradle, network access to fetch them, or emulator. The Android build and device behavior have not been verified. The included GitHub workflow is a build recipe, not an already-run build.

### Android Studio
1. Extract this ZIP. Open the `GlowShield-Browser` folder in Android Studio.
2. Install Android SDK Platform 35, Build Tools 35.0.0, and JDK 17. This project uses Android Gradle Plugin 8.7.3 and Gradle 8.9. A wrapper is not bundled; configure local Gradle 8.9 or use the GitHub build below.
3. Sync, then Build > Build APK(s) (menu wording may vary). Or run `gradle :app:assembleDebug` from the project root.
4. APK: `app/build/outputs/apk/debug/app-debug.apk`. Minimum Android 8.1 (API 27).

### GitHub Actions (including from a mobile browser)
1. Create a repository you control. Upload the contents of the project folder, including `.github/workflows/build.yml`, at the repository root. Preserve the directory structure (do not upload only the ZIP). A computer with Git may be easier for the nested folders.
2. In Actions, select **Build Android APK**, then **Run workflow**. A push to main or master also triggers the workflow.
3. Once the workflow actually succeeds, download its `GlowShield-Browser-debug-APK` artifact and extract the APK. If a build or lint error occurs, consult the workflow log. The artifact is a debug-signed APK for testing only.
4. For public distribution, generate a release APK with your own securely managed signing key in Android Studio, test it on a device, and use a trusted distribution channel. Do not publish the debug build as a production release. Android/Play Protect may show warnings for sideloaded or unfamiliar apps; this project does not bypass those warnings.

## Protection and limitations
- Small, offline, manually maintained starter lists for known ad/tracker hosts and adult domains, plus narrow URL rules. Not a full EasyList implementation or a live threat intelligence database. Does not reliably block first-party, YouTube, or server-inserted ads; resource redirects and service-worker behavior can limit coverage.
- Adult sites detected by hostname show a warning and are blocked without a bypass button. The list is incomplete, may misclassify websites, and does not classify individual videos/images or adult material on mainstream platforms. Not a parental-control system; users can use other browsers.
- New-window and automatic popup requests are restricted; known ad-domain navigation is blocked. First-party in-page overlays are not universally blocked. Counts only include requests the app explicitly counts, not every blocked request.
- HTTPS only, invalid TLS certificates rejected, credential-bearing/ambiguous addresses rejected, third-party cookies disabled, mixed content disabled, dangerous external schemes denied. Internationalized/punycode hostnames and IP addresses are conservatively rejected; legitimate sites may be affected.
- Android Safe Browsing is requested and navigation is blocked if initialization fails. Detection can happen after a request is initiated, and unknown malware/phishing can still evade detection. No claim that all threats can be identified before any network traffic. No third-party DNS or custom proxy.
- Camera, microphone, location, file picker, arbitrary downloads, new windows and service-worker network loads are disabled by design. Some legitimate websites will not work, including some sign-in, upload, download, and PWA flows. Standard JavaScript and DOM storage are enabled for compatibility; no native JS bridge is exposed.
- Single tab, in-session navigation, and a clear browsing data action. Cookies and web storage may persist until cleared. Not anonymous/incognito. Clearing local browser data cannot erase records held by websites or providers.
- This is a prototype, not an audited or production-hardened browser. Keep Android System WebView updated.

## Testing
`bash tests/run.sh` runs the standalone Java URL filtering tests, without Android dependencies. At packaging time 21 rule tests passed. They do not test Android API calls, actual web traffic, popup behavior or Safe Browsing.

Suggested device smoke tests after building: open example.com; search; test back and forward; open an HTTP address and confirm the warning; use a known adult-domain URL without visiting it in another browser and confirm the local warning; verify popup behavior with a controlled test page; verify certificate rejection using a controlled invalid-certificate HTTPS site; clear browsing data and verify session history/cookies are gone; check keyboard and edge-to-edge layout on Android 8.1 and Android 15+.
