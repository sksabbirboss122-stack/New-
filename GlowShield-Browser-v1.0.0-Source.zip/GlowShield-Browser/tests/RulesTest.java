import com.hamza.glowshield.Rules;
public class RulesTest {
    static int count=0;
    static void eq(Object a,Object b){count++;if(!a.equals(b))throw new AssertionError(a+" != "+b);}
    public static void main(String[] args){
        eq(Rules.check("https://example.com"),Rules.Verdict.ALLOW);
        eq(Rules.check("https://www.google.com/search?q=adult"),Rules.Verdict.ALLOW);
        eq(Rules.check("https://ads.doubleclick.net/redirect"),Rules.Verdict.AD_TRACKER);
        eq(Rules.check("http://example.com"),Rules.Verdict.INSECURE);
        eq(Rules.check("https://www.pornhub.com/"),Rules.Verdict.ADULT);
        eq(Rules.check("https://PORNHUB.COM./"),Rules.Verdict.ADULT);
        eq(Rules.check("https://porn.example.com"),Rules.Verdict.ADULT);
        eq(Rules.check("https://example.xxx"),Rules.Verdict.ADULT);
        eq(Rules.check("https://notpornhub.com"),Rules.Verdict.ALLOW);
        eq(Rules.check("https://example.com@evil.com"),Rules.Verdict.SUSPICIOUS);
        eq(Rules.check("https://127.0.0.1"),Rules.Verdict.SUSPICIOUS);
        eq(Rules.check("https://xn--e1afmkfd.xn--p1ai"),Rules.Verdict.SUSPICIOUS);
        eq(Rules.check("file:///etc/passwd"),Rules.Verdict.UNSUPPORTED);
        eq(Rules.check("javascript:alert(1)"),Rules.Verdict.UNSUPPORTED);
        eq(Rules.check("intent://example.com"),Rules.Verdict.UNSUPPORTED);
        eq(Rules.check("https://example.com%2f.evil.com"),Rules.Verdict.SUSPICIOUS);
        eq(Rules.blockResource("https://ads.doubleclick.net/pagead/test","example.com"),true);
        eq(Rules.blockResource("https://example.com/js/adsbygoogle.js","example.com"),true);
        eq(Rules.blockResource("https://doubleclick.net.example.com/assets/a.js","example.com"),false);
        eq(Rules.blockResource("https://cdn.example.com/image.png","example.com"),false);
        eq(Rules.blockResource("https://www.xnxx.com/image.png","example.com"),true);
        System.out.println(count+" rule tests passed");
    }
}
