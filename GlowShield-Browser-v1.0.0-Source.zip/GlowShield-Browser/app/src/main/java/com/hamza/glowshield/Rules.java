package com.hamza.glowshield;

import java.net.URI;
import java.net.IDN;
import java.util.Locale;
import java.util.Set;
import java.util.HashSet;
import java.util.Arrays;

/** Conservative, offline starter rules. Not a comprehensive reputation service. */
public final class Rules {
    public enum Verdict { ALLOW, ADULT, AD_TRACKER, INSECURE, SUSPICIOUS, UNSUPPORTED }
    private static final Set<String> ADULT = set("pornhub.com","xvideos.com","xnxx.com","xhamster.com","redtube.com","youporn.com","tube8.com","spankbang.com","chaturbate.com","stripchat.com","livejasmin.com","youjizz.com","brazzers.com","onlyfans.com","fansly.com","beeg.com","rule34.xxx","fapello.com","hentaihaven.xxx","erome.com","nhentai.net","motherless.com","eporner.com","tnaflix.com","porn.com","xhamsterlive.com","bongacams.com","cam4.com","adultfriendfinder.com");
    private static final Set<String> ADULT_LABELS = set("porn","porno","pornhub","xvideos","xnxx","xhamster","redtube","youporn","hentai","xxx","sexcam","sexcams","pornvideo","pornvideos","adultvideo","adultvideos");
    private static final Set<String> ADS = set("doubleclick.net","googlesyndication.com","googleadservices.com","adservice.google.com","adnxs.com","adsrvr.org","advertising.com","taboola.com","outbrain.com","criteo.com","criteo.net","rubiconproject.com","pubmatic.com","openx.net","indexexchange.com","adform.net","adroll.com","smartadserver.com","casalemedia.com","moatads.com","scorecardresearch.com","quantserve.com","popads.net","popcash.net","propellerads.com","adsterra.com","exoclick.com","trafficjunky.net","mgid.com","revcontent.com","infolinks.com","zedo.com","adcolony.com","applovin.com","unityads.unity3d.com","chartboost.com","google-analytics.com","analytics.google.com","hotjar.com","hotjar.io","clarity.ms","segment.io","amplitude.com","mixpanel.com","mathtag.com","demdex.net","bluekai.com","bidswitch.net","yieldmo.com","sharethrough.com","adition.com","adscale.de","admedia.com","media.net","smaato.net","inmobi.com","adlooxtracking.com","servedby-buysellads.com");
    private static Set<String> set(String... values){ return new HashSet<>(Arrays.asList(values)); }
    private static String normal(String s) {
        if(s==null) return "";
        String h=s.toLowerCase(Locale.ROOT);
        while(h.endsWith(".")) h=h.substring(0,h.length()-1);
        try { return IDN.toASCII(h, IDN.USE_STD3_ASCII_RULES); } catch(Exception ex){ return ""; }
    }
    public static String host(String url) {
        try { URI u=new URI(url); String h=u.getHost(); return normal(h); } catch(Exception e){return "";}
    }
    private static boolean matches(String host,Set<String> list){
        for(String entry:list) if(host.equals(entry)||host.endsWith("."+entry)) return true;
        return false;
    }
    public static boolean isAdult(String host){
        if(matches(host,ADULT)) return true;
        for(String label:host.split("\\.")) if(ADULT_LABELS.contains(label))return true;
        return host.endsWith(".sex")||host.endsWith(".porn")||host.endsWith(".adult");
    }
    public static Verdict check(String url){
        if(url==null || url.length()>8192) return Verdict.SUSPICIOUS;
        try {
            URI u=new URI(url); String scheme=u.getScheme();
            if(scheme==null) return Verdict.UNSUPPORTED;
            if(!scheme.equalsIgnoreCase("https")&&!scheme.equalsIgnoreCase("http"))return Verdict.UNSUPPORTED;
            if(u.getRawUserInfo()!=null || u.getRawAuthority()==null || u.getRawAuthority().contains("\\") || u.getRawAuthority().contains("%"))return Verdict.SUSPICIOUS;
            String h=host(url);
            if(h.isEmpty() || !h.contains(".") || h.matches("[0-9.]+") || h.contains("xn--") || h.endsWith(".local") || h.endsWith(".localhost"))return Verdict.SUSPICIOUS;
            if(isAdult(h))return Verdict.ADULT;
            if(matches(h,ADS))return Verdict.AD_TRACKER;
            if(!scheme.equalsIgnoreCase("https"))return Verdict.INSECURE;
            return Verdict.ALLOW;
        }catch(Exception ex){return Verdict.SUSPICIOUS;}
    }
    public static boolean blockResource(String url,String topHost){
        String h=host(url); if(h.isEmpty()) return false;
        if(matches(h,ADS)||isAdult(h))return true;
        try {
            URI u=new URI(url); String p=u.getPath(); if(p==null)return false;
            p=p.toLowerCase(Locale.ROOT);
            // A narrow set of ad/tracker paths. No blanket third-party blocking.
            return p.contains("/pagead/")||p.contains("/adsbygoogle")||p.endsWith("/gtag/js")||p.endsWith("/adserver.js")||p.endsWith("/popunder.js")||p.endsWith("/popads.js")||p.endsWith("/prebid.js")||p.endsWith("/prebid.min.js")||p.endsWith("/analytics.js")||p.endsWith("/fbevents.js");
        }catch(Exception ex){return false;}
    }
    private Rules(){}
}
