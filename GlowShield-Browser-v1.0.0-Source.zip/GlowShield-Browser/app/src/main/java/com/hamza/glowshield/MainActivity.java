package com.hamza.glowshield;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.net.http.SslError;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import android.webkit.*;
import java.io.ByteArrayInputStream;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends Activity {
    private static final int BG=0xfff0f7f5, INK=0xff12332f, TEAL=0xff087f73, MUTED=0xff506b66;
    private WebView web; private EditText address; private TextView status, counts; private FrameLayout content;
    private LinearLayout home; private View warning; private String lastGood=""; private volatile String topHost="";
    private final AtomicInteger ads=new AtomicInteger(), popups=new AtomicInteger();
    private boolean safeReady=false, active=false, clearing=false;
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    private GradientDrawable bg(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(r));return d;}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    private Button button(String s,Runnable action){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(TEAL);b.setTextSize(15);b.setMinHeight(dp(44));b.setMinimumWidth(0);b.setMinWidth(0);b.setPadding(dp(8),0,dp(8),0);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xffe0efeb));b.setOnClickListener(v->action.run());return b;}
    private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private void spacer(LinearLayout l,int h){l.addView(new View(this),new LinearLayout.LayoutParams(1,dp(h)));}
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        LinearLayout root=column();root.setBackgroundColor(BG);setContentView(root);
        if(android.os.Build.VERSION.SDK_INT>=30) root.setOnApplyWindowInsetsListener((v,insets)->{android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());android.graphics.Insets ime=insets.getInsets(WindowInsets.Type.ime());v.setPadding(bars.left,bars.top,bars.right,Math.max(bars.bottom,ime.bottom));return insets;}); else root.setFitsSystemWindows(true);
        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);head.setPadding(dp(12),dp(5),dp(12),dp(3));
        TextView brand=text("◆  GlowShield",21,INK,true);head.addView(brand,new LinearLayout.LayoutParams(0,dp(40),1));brand.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(button("সুরক্ষা",()->showInfo()));root.addView(head);
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(12),0,dp(12),0);
        address=new EditText(this);address.setSingleLine(true);address.setTextSize(15);address.setTextColor(INK);address.setHintTextColor(MUTED);address.setHint("ওয়েবসাইট অথবা সার্চ");address.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_URI);address.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_GO);address.setPadding(dp(12),0,dp(12),0);address.setBackground(bg(Color.WHITE,14));
        bar.addView(address,new LinearLayout.LayoutParams(0,dp(48),1));Button go=button("যান",()->navigateInput());LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(dp(64),dp(48));gp.leftMargin=dp(6);bar.addView(go,gp);root.addView(bar);
        address.setOnEditorActionListener((v,id,event)->{if(id==android.view.inputmethod.EditorInfo.IME_ACTION_GO||(event!=null&&event.getKeyCode()==KeyEvent.KEYCODE_ENTER&&event.getAction()==KeyEvent.ACTION_DOWN)){navigateInput();return true;}return false;});
        LinearLayout meta=new LinearLayout(this);meta.setPadding(dp(14),dp(8),dp(14),dp(8));meta.setGravity(Gravity.CENTER_VERTICAL);
        status=text("সুরক্ষা চালু হচ্ছে…",12,MUTED,false);meta.addView(status,new LinearLayout.LayoutParams(0,-2,1));counts=text("০ ব্লক",12,TEAL,true);meta.addView(counts);root.addView(meta);
        content=new FrameLayout(this);root.addView(content,new LinearLayout.LayoutParams(-1,0,1));
        web=new WebView(this);web.setVisibility(View.GONE);content.addView(web,new FrameLayout.LayoutParams(-1,-1));configureWeb();
        home=column();home.setPadding(dp(24),dp(26),dp(24),dp(20));home.setGravity(Gravity.CENTER_HORIZONTAL);home.setBackgroundColor(BG);
        ScrollView homeScroll=new ScrollView(this);homeScroll.setFillViewport(true);homeScroll.addView(home);content.addView(homeScroll,new FrameLayout.LayoutParams(-1,-1));homeScroll.setTag("home");
        TextView shield=text("◆",65,TEAL,true);home.addView(shield);home.addView(text("নিরাপদ ব্রাউজিং",28,INK,true));spacer(home,10);
        TextView intro=text("বিজ্ঞাপন, ট্র্যাকার ও অনাকাঙ্ক্ষিত পপ-আপ কমান। সন্দেহজনক এবং পরিচিত ১৮+ সাইটে সতর্কতা দেখুন।",16,MUTED,false);intro.setGravity(Gravity.CENTER);home.addView(intro);spacer(home,28);
        for(String s:new String[]{"✓  বিজ্ঞাপন ও ট্র্যাকার ফিল্টার","✓  পপ-আপ ও নতুন উইন্ডো ব্লক","✓  HTTPS ও Safe Browsing","✓  পরিচিত ১৮+ সাইট ব্লক"}){TextView item=text(s,16,INK,true);item.setPadding(dp(15),dp(14),dp(15),dp(14));item.setBackground(bg(Color.WHITE,14));home.addView(item,new LinearLayout.LayoutParams(-1,-2));spacer(home,8);}
        spacer(home,10);TextView note=text("কোনো ফিল্টার শতভাগ সাইট বা বিজ্ঞাপন শনাক্ত করতে পারে না।",13,MUTED,false);note.setGravity(Gravity.CENTER);home.addView(note);
        LinearLayout nav=new LinearLayout(this);nav.setPadding(dp(8),dp(4),dp(8),dp(4));for(String s:new String[]{"‹","›","↻","হোম","⋮"}){Runnable r;switch(s){case "‹":r=()->back();break;case "›":r=()->{if(warning==null&&web.isShown()&&web.canGoForward())web.goForward();};break;case "↻":r=()->{if(warning==null&&web.isShown())web.reload();};break;case "হোম":r=()->showHome();break;default:r=()->menu();}nav.addView(button(s,r),new LinearLayout.LayoutParams(0,dp(48),1));}root.addView(nav);
        WebView.startSafeBrowsing(this,ok->{if(!isFinishing()&&!isDestroyed()){safeReady=Boolean.TRUE.equals(ok);status.setText(safeReady?"সুরক্ষা চালু":"Safe Browsing অনুপলব্ধ");}});
    }
    private void configureWeb(){
        WebView.setWebContentsDebuggingEnabled(false);
        WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(false);s.setAllowContentAccess(false);s.setAllowFileAccessFromFileURLs(false);s.setAllowUniversalAccessFromFileURLs(false);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);s.setSafeBrowsingEnabled(true);s.setJavaScriptCanOpenWindowsAutomatically(false);s.setSupportMultipleWindows(true);s.setGeolocationEnabled(false);s.setMediaPlaybackRequiresUserGesture(true);s.setSaveFormData(false);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web,false);
        web.setDownloadListener((url,userAgent,disposition,mime,length)->{new AlertDialog.Builder(this).setTitle("ডাউনলোড বন্ধ").setMessage("অজানা ফাইল ডাউনলোড এই ব্রাউজারে অনুমোদিত নয়।").setPositiveButton("ঠিক আছে",null).show();});
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onCreateWindow(WebView v,boolean dialog,boolean gesture,android.os.Message msg){popups.incrementAndGet();updateCounts();return false;}
            @Override public void onPermissionRequest(PermissionRequest request){request.deny();}
            @Override public void onGeolocationPermissionsShowPrompt(String origin,GeolocationPermissions.Callback callback){callback.invoke(origin,false,false);}
            @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> cb,FileChooserParams params){cb.onReceiveValue(null);return true;}
        });
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){
                String url=r.getUrl().toString();Rules.Verdict verdict=Rules.check(url);
                if(r.isForMainFrame()){
                    if(verdict!=Rules.Verdict.ALLOW){showWarning(verdict,url);return true;}
                    if(!safeReady){warn("সুরক্ষা এখনো প্রস্তুত নয়","Android Safe Browsing চালু না হওয়ায় ওয়েবসাইট খোলা হয়নি।",url);return true;}
                    topHost=Rules.host(url);return false;
                }
                if(verdict==Rules.Verdict.AD_TRACKER||Rules.blockResource(url,topHost)){ads.incrementAndGet();updateCounts();return true;}
                return verdict!=Rules.Verdict.ALLOW;
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest r){
                String url=r.getUrl().toString();
                if(r.isForMainFrame()){
                    Rules.Verdict verdict=Rules.check(url);
                    if(verdict!=Rules.Verdict.ALLOW){runOnUiThread(()->{if(active)showWarning(verdict,url);});return blocked();}
                }else if(Rules.blockResource(url,topHost)){ads.incrementAndGet();updateCounts();return blocked();}
                return null;
            }
            @Override public void onPageStarted(WebView v,String url,android.graphics.Bitmap icon){
                if(!active)return;Rules.Verdict verdict=Rules.check(url);
                if(verdict!=Rules.Verdict.ALLOW){v.stopLoading();showWarning(verdict,url);return;}
                topHost=Rules.host(url);address.setText(url);status.setText("সাইট লোড হচ্ছে…");
            }
            @Override public void onPageFinished(WebView v,String url){if(active&&warning==null&&Rules.check(url)==Rules.Verdict.ALLOW){lastGood=url;status.setText("HTTPS • ফিল্টার চালু");}}
            @Override public void onReceivedSslError(WebView v,SslErrorHandler handler,SslError error){handler.cancel();if(active)warn("সার্টিফিকেট সমস্যা","সাইটের TLS/SSL সার্টিফিকেট যাচাই হয়নি। সংযোগ বন্ধ করা হয়েছে।",error.getUrl());}
            @Override public void onSafeBrowsingHit(WebView v,WebResourceRequest r,int threatType,SafeBrowsingResponse response){response.backToSafety(false);if(active)warn("ঝুঁকিপূর্ণ ওয়েবসাইট","Android Safe Browsing ম্যালওয়্যার, ফিশিং বা ক্ষতিকর কনটেন্টের সম্ভাবনা শনাক্ত করেছে। সাইটটি বন্ধ করা হয়েছে।",r.getUrl().toString());}
            @Override public void onReceivedError(WebView v,WebResourceRequest r,WebResourceError error){if(r.isForMainFrame()&&active&&warning==null)warn("সাইট খোলা যায়নি","ইন্টারনেট সংযোগ, DNS অথবা ওয়েবসাইটের সমস্যা থাকতে পারে।",r.getUrl().toString());}
            @Override public boolean onRenderProcessGone(WebView v,RenderProcessGoneDetail detail){active=false;((FrameLayout)v.getParent()).removeView(v);v.destroy();web=new WebView(MainActivity.this);content.addView(web,0,new FrameLayout.LayoutParams(-1,-1));web.setVisibility(View.GONE);configureWeb();showHome();new AlertDialog.Builder(MainActivity.this).setTitle("ব্রাউজার পুনরুদ্ধার").setMessage("ওয়েব রেন্ডারার বন্ধ হয়েছিল। আবার চেষ্টা করুন।").setPositiveButton("ঠিক আছে",null).show();return true;}
        });
        // Service-worker requests are separate from normal WebView resource callbacks.
        ServiceWorkerController sw=ServiceWorkerController.getInstance();ServiceWorkerWebSettings ws=sw.getServiceWorkerWebSettings();ws.setAllowContentAccess(false);ws.setAllowFileAccess(false);ws.setBlockNetworkLoads(true);
    }
    private WebResourceResponse blocked(){return new WebResourceResponse("text/plain","UTF-8",403,"Blocked",java.util.Collections.singletonMap("Cache-Control","no-store"),new ByteArrayInputStream(new byte[0]));}
    private void updateCounts(){runOnUiThread(()->counts.setText(ads.get()+" বিজ্ঞাপন/ট্র্যাকার • "+popups.get()+" পপ-আপ"));}
    private void navigateInput(){String q=address.getText().toString().trim();if(q.isEmpty())return;((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(address.getWindowToken(),0);address.clearFocus();String url;
        if(q.matches("^[A-Za-z][A-Za-z0-9+.-]*:.*")&&!q.matches("^[^ /]+\\.[^ /]+:[0-9]+.*"))url=q;
        else if(!q.contains(" ")&&q.contains("."))url="https://"+q;
        else url="https://www.google.com/search?q="+Uri.encode(q);
        open(url);
    }
    private void open(String url){if(clearing)return;Rules.Verdict verdict=Rules.check(url);if(verdict!=Rules.Verdict.ALLOW){showWarning(verdict,url);return;}
        if(!safeReady){warn("সুরক্ষা এখনো প্রস্তুত নয়","Android Safe Browsing চালু না হওয়ায় সাইটটি খোলা হয়নি। WebView আপডেট ও ইন্টারনেট সংযোগ পরীক্ষা করুন।",url);return;}
        clearWarning();content.findViewWithTag("home").setVisibility(View.GONE);web.setVisibility(View.VISIBLE);active=true;topHost=Rules.host(url);address.setText(url);web.loadUrl(url);}
    private void showWarning(Rules.Verdict v,String url){switch(v){case AD_TRACKER:warn("বিজ্ঞাপনের লিংক ব্লক","পরিচিত বিজ্ঞাপন বা ট্র্যাকিং নেটওয়ার্কে যাওয়ার চেষ্টা বন্ধ করা হয়েছে।",url);break;case ADULT:warn("১৮+ কনটেন্ট সতর্কতা","এই ঠিকানাটি পরিচিত বা সম্ভাব্য প্রাপ্তবয়স্ক কনটেন্টের সাইট। সুরক্ষার জন্য প্রবেশ বন্ধ করা হয়েছে।",url);break;case INSECURE:warn("অনিরাপদ HTTP সংযোগ","এই সাইট HTTPS ব্যবহার করছে না। সংযোগ বন্ধ করা হয়েছে।",url);break;case SUSPICIOUS:warn("সন্দেহজনক ঠিকানা","এই ঠিকানার গঠন অস্বাভাবিক বা যাচাই করা কঠিন। ভুল শনাক্তকরণও সম্ভব।",url);break;default:warn("অসমর্থিত লিংক","এই ব্রাউজার শুধু HTTPS ওয়েবসাইট খোলে।",url);}}
    private void warn(String heading,String message,String url){if(isFinishing()||isDestroyed())return;active=false;web.stopLoading();web.setVisibility(View.GONE);content.findViewWithTag("home").setVisibility(View.GONE);clearWarning();address.setText(url);status.setText("সুরক্ষা সতর্কতা");
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);LinearLayout panel=column();panel.setGravity(Gravity.CENTER);panel.setPadding(dp(24),dp(25),dp(24),dp(25));panel.setBackgroundColor(0xfffff3e7);scroll.addView(panel);TextView sign=text("!",55,0xffa14a19,true);panel.addView(sign);TextView title=text(heading,25,0xff743616,true);title.setGravity(Gravity.CENTER);panel.addView(title);spacer(panel,12);TextView detail=text(message,16,INK,false);detail.setGravity(Gravity.CENTER);panel.addView(detail);spacer(panel,12);TextView link=text(url.length()>180?url.substring(0,180)+"…":url,13,MUTED,false);link.setGravity(Gravity.CENTER);panel.addView(link);spacer(panel,24);panel.addView(button("নিরাপদ হোমে ফিরুন",()->showHome()),new LinearLayout.LayoutParams(-1,dp(52)));if(!lastGood.isEmpty()){panel.addView(button("আগের পেজ আবার খুলুন",()->open(lastGood)),new LinearLayout.LayoutParams(-1,dp(48)));}warning=scroll;content.addView(scroll,new FrameLayout.LayoutParams(-1,-1));}
    private void clearWarning(){if(warning!=null){content.removeView(warning);warning=null;}}
    private void showHome(){active=false;web.stopLoading();web.setVisibility(View.GONE);clearWarning();content.findViewWithTag("home").setVisibility(View.VISIBLE);address.setText("");status.setText(safeReady?"সুরক্ষা চালু":"Safe Browsing অনুপলব্ধ");}
    private void back(){if(warning!=null){showHome();return;}if(web.isShown()&&web.canGoBack()){web.goBack();return;}showHome();}
    @Override public void onBackPressed(){if(warning!=null||web.isShown())back();else super.onBackPressed();}
    private void showInfo(){new AlertDialog.Builder(this).setTitle("GlowShield সুরক্ষা").setMessage("• পরিচিত বিজ্ঞাপন ও ট্র্যাকার ফিল্টার\n• নতুন উইন্ডো ও পপ-আপ বন্ধ\n• তৃতীয় পক্ষের কুকি বন্ধ\n• পরিচিত ১৮+ সাইটে প্রবেশ বন্ধ\n• HTTPS, SSL যাচাই ও Android Safe Browsing\n• ক্যামেরা, মাইক, লোকেশন ও ফাইল অ্যাক্সেস বন্ধ\n\nফিল্টার সীমিত; নতুন বা প্রথম পক্ষের বিজ্ঞাপন ও ক্ষতিকর সাইট বাদ পড়ে যেতে পারে। Safe Browsing-এর জন্য Android-এর সেবা ব্যবহার হয়।").setPositiveButton("ঠিক আছে",null).show();}
    private void menu(){new AlertDialog.Builder(this).setTitle("ব্রাউজার মেনু").setItems(new String[]{"সুরক্ষার তথ্য","ব্রাউজিং ডেটা মুছুন","হোম"},(d,i)->{if(i==0)showInfo();else if(i==1)clearData();else showHome();}).show();}
    private void clearData(){new AlertDialog.Builder(this).setTitle("ব্রাউজিং ডেটা মুছবেন?").setMessage("কুকি, ক্যাশ, ওয়েব স্টোরেজ ও এই সেশনের হিস্ট্রি মুছে যাবে।").setNegativeButton("না",null).setPositiveButton("মুছুন",(d,i)->{clearing=true;showHome();lastGood="";web.clearHistory();web.clearCache(true);web.clearFormData();content.removeView(web);web.destroy();web=new WebView(this);content.addView(web,0,new FrameLayout.LayoutParams(-1,-1));web.setVisibility(View.GONE);configureWeb();WebStorage.getInstance().deleteAllData();CookieManager.getInstance().removeAllCookies(ok->{CookieManager.getInstance().flush();web.clearHistory();clearing=false;Toast.makeText(this,"ব্রাউজিং ডেটা মুছে দেওয়া হয়েছে",Toast.LENGTH_SHORT).show();});ads.set(0);popups.set(0);updateCounts();}).show();}
    @Override protected void onDestroy(){active=false;if(web!=null){web.stopLoading();web.destroy();}super.onDestroy();}
}
